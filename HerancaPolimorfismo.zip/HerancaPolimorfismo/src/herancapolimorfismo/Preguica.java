package herancapolimorfismo;

public class Preguica extends Animal
{
    String som; 
    
    public Preguica()
    {
        this.nome = "Preguiçosa";
        this.idade = "5";
        this.som = "...";
        this.correr = false;
    }
    
    @Override
    public void emitirSom()
    {
        System.out.println(this.som);
    }
    
    public void subirArvores()
    {
        System.out.println("Subindo em árvores.");
    }
}
