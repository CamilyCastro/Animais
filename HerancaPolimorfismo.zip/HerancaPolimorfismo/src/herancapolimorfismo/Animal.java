package herancapolimorfismo;

public class Animal 
{
    protected String nome;
    protected String idade;
    protected boolean correr;
 
    public void emitirSom()
    {

    }
}
