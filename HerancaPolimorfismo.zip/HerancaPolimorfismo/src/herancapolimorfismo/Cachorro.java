package herancapolimorfismo;

public class Cachorro extends Animal
{
    String som; 
    
    public Cachorro()
    {
        this.nome = "Pipoca";
        this.idade = "7";
        this.som = "Latindo.";
        this.correr = true;
    }
    
    @Override
    public void emitirSom()
    {
        System.out.println(this.som);
    }
    
    public void correr()
    {
        System.out.println("Correndo.");
    }
}
