package herancapolimorfismo;

import java.util.ArrayList;

public class Zoologico
{
    ArrayList<Animal> jaulas = new ArrayList();
    
    public Zoologico(Animal cachorro, Animal cavalo, Animal preguica)
    {
        this.jaulas.add(cachorro);
        this.jaulas.add(cavalo);
        this.jaulas.add(preguica);
        this.jaulas.add(cachorro);
        this.jaulas.add(cavalo);
        this.jaulas.add(preguica);
        this.jaulas.add(cachorro);
        this.jaulas.add(cavalo);
        this.jaulas.add(preguica);
        this.jaulas.add(cachorro);
    }
    
    public void percorrer()
    {
        for(Animal animal: this.jaulas)
        {
            animal.emitirSom();
            if(animal.correr == true){
                System.out.println("Correndo");
            }
        }
    }
    
    
    
}
