package herancapolimorfismo;

public class Cavalo extends Animal
{
    String som; 
    
    public Cavalo()
    {
        this.nome = "Grandão";
        this.idade = "9";
        this.som = "Relinchando.";
        this.correr = true;
    }
    
    @Override
    public void emitirSom()
    {
        System.out.println(this.som);
    }
    
    public void correr()
    {
        System.out.println("Correndo.");
    }
}
