package herancapolimorfismo;

public class HerancaPolimorfismo
{
    public static void main(String[] args) 
    {
        Cachorro cachorro = new Cachorro();
        Cavalo cavalo = new Cavalo();
        Preguica preguica = new Preguica();
        Veterinario vet = new Veterinario();
        
        /*cachorro.emitirSom();
        cavalo.emitirSom();
        preguica.emitirSom();
        
        vet.examinar(cachorro);
        vet.examinar(cavalo);
        vet.examinar(preguica);*/
        
        Zoologico zoo = new Zoologico(cachorro, cavalo, preguica);
        zoo.percorrer();
        
        
    }
    
}
