package herancapolimorfismo;

public class Veterinario
{
    //Animal animal = new Animal();
    
    public Veterinario()
    {
        
    }
    
    public void  examinar(Animal animal)
    {
        animal.emitirSom();
    }
}
